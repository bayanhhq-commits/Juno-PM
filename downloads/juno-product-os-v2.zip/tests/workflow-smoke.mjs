import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import vm from "node:vm";
import { webcrypto } from "node:crypto";

class FakeClassList {
  constructor() { this.values = new Set(); }
  add(...values) { values.forEach((value) => this.values.add(value)); }
  remove(...values) { values.forEach((value) => this.values.delete(value)); }
  toggle(value, force) {
    const enabled = force === undefined ? !this.values.has(value) : Boolean(force);
    enabled ? this.values.add(value) : this.values.delete(value);
    return enabled;
  }
}

class FakeElement {
  constructor(key, document) {
    this.key = key;
    this.ownerDocument = document;
    this.classList = new FakeClassList();
    this.dataset = {};
    this.style = {};
    this.value = "";
    this.textContent = "";
    this.innerHTML = "";
    this.className = "";
    this.disabled = false;
    this.checked = false;
  }
  addEventListener() {}
  querySelector(selector) { return this.ownerDocument.querySelector(`${this.key} ${selector}`); }
  closest() { return this; }
  showModal() { this.open = true; }
  close() { this.open = false; }
  reset() {}
  click() {}
}

class FakeDocument {
  constructor() { this.elements = new Map(); }
  querySelector(selector) {
    if (!this.elements.has(selector)) this.elements.set(selector, new FakeElement(selector, this));
    return this.elements.get(selector);
  }
  querySelectorAll() { return []; }
  createElement(tag) { return new FakeElement(tag, this); }
}

const storage = new Map();
const document = new FakeDocument();
const context = vm.createContext({
  console,
  structuredClone,
  crypto: webcrypto,
  document,
  localStorage: {
    getItem: (key) => storage.get(key) ?? null,
    setItem: (key, value) => storage.set(key, value),
    removeItem: (key) => storage.delete(key)
  },
  Blob,
  URL,
  Date,
  confirm: () => false,
  setTimeout: () => 1,
  clearTimeout: () => {}
});

const source = await readFile(new URL("../app.js", import.meta.url), "utf8");
vm.runInContext(source, context, { filename: "app.js" });

const run = (expression) => vm.runInContext(expression, context);
const read = (expression) => JSON.parse(run(`JSON.stringify(${expression})`));

assert.equal(run("state.opportunities.length"), 4, "loads the four sample roadmap candidates");
assert.equal(run("ARTIFACTS.length"), 13, "defines the complete 13-artifact product pack");
assert.equal(run("Object.keys(PATHS).length"), 4, "offers four lifecycle paths");
assert.equal(run("state.mode"), "Strategy Mode", "detects approved strategy context");
assert.equal(run('calculatePriority(getOpportunity("OPP-004"))'), "P3", "blocks uncited ideas at P3");

const parsedUsage = read('parseUsageCsv("module,users,active_users,completion_rate\\nReports,10,8,70")');
assert.deepEqual(parsedUsage, [{ module: "Reports", users: 10, active: 8, completion: 70 }]);

run("recalculatePriorities()");
assert.equal(run('getOpportunity("OPP-004").status'), "Insufficient evidence");

run('state.selectedPackItem = "OPP-001"; generatePack()');
assert.equal(run('Object.keys(state.artifacts["OPP-001"]).length'), 13);
assert.match(run('state.artifacts["OPP-001"].fullPrd'), /Acceptance criteria/);

const priorStage = run('getOpportunity("OPP-001").stage');
run('advanceStage("OPP-001")');
assert.equal(run('getOpportunity("OPP-001").stage'), priorStage + 1, "advances only through an explicit gate");

run('state.selectedLaunchItem = "OPP-001"; approveRelease()');
assert.equal(run('state.launchApproved["OPP-001"]'), false, "holds release while checks are incomplete");
run('Object.values(state.launchChecks["OPP-001"]).flat().forEach((check) => { check.done = true; }); approveRelease()');
assert.equal(run('state.launchApproved["OPP-001"]'), true, "records explicit release approval after readiness reaches 100%");

run("activateKillSwitch()");
const killedStage = run('getOpportunity("OPP-001").stage');
run('advanceStage("OPP-001")');
assert.equal(run('getOpportunity("OPP-001").stage'), killedStage, "kill switch blocks lifecycle transitions");
run("clearKillSwitch()");

const versionsBeforeRestore = run("state.versions.length");
run("restoreLastApproved()");
assert.equal(run("state.versions.length"), versionsBeforeRestore + 1, "restore appends a new version instead of deleting history");
assert.ok(run("state.events.length") >= 8, "keeps an audit trail across the tested workflow");

console.log("Juno workflow smoke test passed: knowledge, prioritization, paths, product pack, release gates, kill switch, and restore.");
