# Juno Product OS · Local Prototype

This local-first prototype demonstrates an end-to-end AI product-management
workflow:

1. Knowledge and module-usage ingestion
2. Evidence-backed opportunity prioritization
3. Now / Next / Later roadmap planning
4. Lifecycle routing through Fast Validation, Standard Product, High-Risk, or
   Reliability Fix paths
5. Product-pack generation: opportunity brief, one-pager, full PRD, prototype
   brief, epic, stories, analytics, UAT, GTM, rollout, release notes, user manual,
   and post-launch review
6. Release readiness and explicit approval gates
7. Append-only versions, audit, undo, discard, restore, snapshot export, and a
   kill switch

## Local use

The easiest option is to open `index.html` directly in a modern browser. The
workspace is saved only in that browser.

If you prefer a local URL, serve this directory with any static web server. For
example:

    python3 -m http.server 4173 --bind 127.0.0.1

Then open http://127.0.0.1:4173.

The prototype uses browser storage only. Imported TXT, Markdown, JSON, and CSV
files stay in the browser. No API, model, GitHub repository, or external system
is contacted.

## Reversibility

- Product decisions create append-only versions in **Control & Audit**.
- **Undo**, **discard draft**, and **restore approved** create recovery versions;
  they do not delete history.
- **Export snapshot** saves a portable local backup before major changes.
- The kill switch blocks analysis, approvals, lifecycle changes, generation,
  and exports until it is cleared.
- This V2 folder is separate from the original V1 backup. Removing V2 does not
  change V1.

This is a functional workflow prototype and deterministic policy simulator. A
production AI version still requires a document parser, permission-aware RAG,
an LLM, evaluation, and an approved persistence layer.
