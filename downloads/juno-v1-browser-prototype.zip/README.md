# Juno Local PM Agent

Run from this directory:

    python3 -m http.server 4173 --bind 127.0.0.1

Then open http://127.0.0.1:4173.

This browser-only policy simulator uses no API, network service, or external
data store. It tests evidence-aware scoring, the approval gate, local export,
append-only undo/restore, cancel, discard, and the kill switch. It is not a
live LLM or RAG implementation.
